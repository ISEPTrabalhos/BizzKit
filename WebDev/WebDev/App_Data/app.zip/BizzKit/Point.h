#ifndef __BizzKit__Point__
#define __BizzKit__Point__

#include "GlobalVars.h"

class Point {
public:
    GLfloat x,y,z;
};

#endif
