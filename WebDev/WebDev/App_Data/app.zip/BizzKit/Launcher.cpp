#ifdef __APPLE__
    #pragma GCC diagnostic ignored "-Wwarning-flag"
#endif

#include "Maze.h"

int main(int argc, char **argv){
	Maze::Launch(argc, argv);

	return 0;
}